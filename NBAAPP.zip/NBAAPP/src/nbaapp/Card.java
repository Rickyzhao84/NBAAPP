/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nbaapp;

/**
 *
 * @author ricky
 */
public class Card {
    public int[] value = {80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99};

    int[] card = new int[20];
    
    
    
}
