/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nbaapp;

import java.util.Random;

/**
 *
 * @author ricky
 */
public class Number {
    public int value;

    public Number(int value) {
        value = 0;
        
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    
    public void Value(){
        Random number = new Random();
        int vl =number.nextInt(8) * 12;
        
        int v2 =number.nextInt(8) * 12;
        int v3 =number.nextInt(8) * 12;
        int v4 =number.nextInt(8) * 12;
        int v5 =number.nextInt(8) * 12;
        
        
        
    }
    
}
